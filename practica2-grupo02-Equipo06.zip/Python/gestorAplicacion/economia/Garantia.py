﻿from enum import Enum

class Garantia(Enum):
    VIVIENDA = 0
    LOTE = 1
    CARRO = 2
    MOTO = 3
