﻿from gestorAplicacion.usuario import Cuenta

class Abonable:
    def abonar(self, monto, origen):
        pass
    def getDivisa(self):
        pass
    def terminar(self, cuenta):
        pass
