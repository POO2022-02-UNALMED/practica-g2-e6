﻿class Contable:
    def getSaldo(self):
        pass
    def getDivisa(self):
        pass
